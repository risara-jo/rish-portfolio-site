import { useFrame, useThree } from '@react-three/fiber'
import { useEffect, useRef } from 'react'
import * as THREE from 'three'

export default function ScrollManager({ onSectionChange }: { onSectionChange: (s: number) => void }) {
  const { camera } = useThree()
  const scrollRef = useRef(0)
  const currentSection = useRef(0)

  // Transition states
  const targetPosition = useRef(new THREE.Vector3())
  const targetLookAt = useRef(new THREE.Vector3())
  const targetFov = useRef(camera instanceof THREE.PerspectiveCamera ? camera.fov : 50) // Default FOV for fallback

  // Easing function (easeInOutCubic)
  const ease = (t: number) => t < 0.5
    ? 4 * t * t * t
    : 1 - Math.pow(-2 * t + 2, 3) / 2

  // Smooth interpolation
  function lerpVec3(start: THREE.Vector3, end: THREE.Vector3, alpha: number) {
    return new THREE.Vector3(
      start.x + (end.x - start.x) * alpha,
      start.y + (end.y - start.y) * alpha,
      start.z + (end.z - start.z) * alpha
    )
  }

  useEffect(() => {
    const handleScroll = () => {
      const scrollY = window.scrollY
      scrollRef.current = scrollY
      const section = Math.floor(scrollY / window.innerHeight)

      if (section !== currentSection.current) {
        currentSection.current = section
        onSectionChange(section)

        // Set transition targets
        switch (section) {
          case 0:
            targetPosition.current.set(2.81, 7.6, 15.86)
            targetLookAt.current.set(0, 4, 0)
            targetFov.current = 45
            break
          case 1:
            targetPosition.current.set(100, -450, 50)
            targetLookAt.current.set(0, 10, 0)
            targetFov.current = 50
            break
          case 2:
            targetPosition.current.set(2.81, 100, 15.86)
            targetLookAt.current.set(-1, 0, 2)
            targetFov.current = 40
            break
        }
      }
    }

    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [onSectionChange])

  useFrame((_, delta) => {
    const lerpSpeed = ease(delta * 3) // smooth transition curve

    // Camera position
    camera.position.lerp(targetPosition.current, lerpSpeed)

    // Camera FOV (zoom)
    if (camera instanceof THREE.PerspectiveCamera) {
      camera.fov += (targetFov.current - camera.fov) * lerpSpeed
      camera.updateProjectionMatrix()
    }

    // LookAt
    const currentLookAt = new THREE.Vector3()
    camera.getWorldDirection(currentLookAt)
    const newLookAt = lerpVec3(currentLookAt, targetLookAt.current, lerpSpeed)
    camera.lookAt(newLookAt)
  })

  return null
}
