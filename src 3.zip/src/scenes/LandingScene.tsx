// src/scenes/LandingScene.tsx
import { useEffect, useRef } from 'react'
import { useThree, useFrame } from '@react-three/fiber'
import * as THREE from 'three'
import AnimeSky from '@/components/AnimeSky'
import AnimatedPlane from '@/components/AnimatedPlane'
import LandingText from '@/components/LandingText'

export default function LandingScene() {
  const { camera } = useThree()
  const targetPosition = useRef(new THREE.Vector3(-10, 15, -20))

  // Update targetPosition based on scroll
  useEffect(() => {
    const handleScroll = () => {
      const scrollY = window.scrollY
      const y = 15 + scrollY * 0.02
      const z = -20 + scrollY * 0.05
      targetPosition.current.set(-10, y, z)
    }

    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  // Smoothly update camera position every frame
  useFrame(() => {
    camera.position.lerp(targetPosition.current, 0.05)
    camera.lookAt(0, 0, 0)
  })

  return (
    <>
      <AnimeSky position={[0, 0, 0]} />
      <AnimatedPlane position={[0, 0, -5]} scale={1} rotation={[0, Math.PI, 0]} />
      <LandingText />
    </>
  )
}
