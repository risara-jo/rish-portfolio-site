import Head from 'next/head'
import { Canvas } from '@react-three/fiber'
import { OrbitControls } from '@react-three/drei'
import { useState } from 'react'
import LandingScene from '@/scenes/LandingScene'
import ScrollManager from '@/components/ScrollManager'
import LandingText from '@/components/LandingText'
import ProjectsText from '@/components/ProjectsText'

export default function Home() {
  const [section, setSection] = useState(0)

  return (
    <>
      <Head>
        <title>Rish Portfolio</title>
      </Head>

      {/* UI rendered outside Canvas */}
      {section === 0 && <LandingText />}
      {section === 1 && <ProjectsText />}

      <main className="h-screen w-screen">
        <Canvas
          shadows
          camera={{ position: [0, 10, 20], fov: 35 }}
          style={{ position: 'fixed', top: 0, left: 0, width: '100%', height: '100%' }}
        >
          <OrbitControls enableZoom={true} enablePan={true} enableRotate={true} />
          <LandingScene />
          <ScrollManager onSectionChange={setSection} />
        </Canvas>

        {/* Scroll container */}
        <div style={{ height: '4000px', position: 'relative', zIndex: 10 }} />
      </main>
    </>
  )
}
