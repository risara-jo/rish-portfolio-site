import { useFrame, useThree } from '@react-three/fiber'
import { useEffect, useRef, useState } from 'react'
import { createPortal } from 'react-dom'
import LandingText from './LandingText'
import ProjectsText from './ProjectsText'

export default function ScrollManager() {
  const { camera, gl } = useThree()
  const scrollRef = useRef<number>(0)
  const [section, setSection] = useState(0)

  useEffect(() => {
    const handleScroll = () => {
      const y = window.scrollY
      scrollRef.current = y
      const newSection = Math.floor(y / window.innerHeight)
      setSection(newSection)
    }

    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  useFrame(() => {
    const scroll = scrollRef.current

    if (scroll < window.innerHeight) {
      camera.position.lerp({ x: 2.81, y: 7.60, z: 15.86 }, 0.1)
      camera.lookAt(0, 0, 0)
    } else {
      camera.position.lerp({ x: 1.35, y: -130.37, z: 39.24 }, 0.1)
      camera.lookAt(0, -130, 0)
    }
  })

  return (
    <>
      {createPortal(section === 0 ? <LandingText /> : null, gl.domElement.parentNode as Element)}
      {createPortal(section === 1 ? <ProjectsText /> : null, gl.domElement.parentNode as Element)}
    </>
  )
}
