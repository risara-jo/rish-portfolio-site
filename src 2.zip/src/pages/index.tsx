// src/pages/index.tsx
import Head from 'next/head'
import { Canvas } from '@react-three/fiber'
import LandingScene from '@/scenes/LandingScene'

export default function Home() {
  return (
    <>
      <Head>
        <title>Rish Portfolio</title>
      </Head>
      <main className="h-screen w-screen">
        <Canvas
          shadows
          camera={{ position: [-10, 15, -20], fov: 25 }}
          style={{ background: 'transparent' }}
        >
          {/* Lighting */}
          <ambientLight intensity={1.2} />
          <directionalLight
            position={[0, 30, 10]}
            intensity={1.5}
            castShadow
            shadow-mapSize-width={1024}
            shadow-mapSize-height={1024}
          />
          <hemisphereLight color={'white'} groundColor={'black'} intensity={0.5} />

          {/* Scene */}
          <LandingScene />

          {/* No OrbitControls to disable dragging */}
        </Canvas>
      </main>
    </>
  )
}
