// src/scenes/LandingScene.tsx
import { useEffect, useRef } from 'react'
import { useThree, useFrame } from '@react-three/fiber'
import AnimeSky from '@/components/AnimeSky'
import AnimatedPlane from '@/components/AnimatedPlane'
import LandingText from '@/components/LandingText'
import * as THREE from 'three'

export default function LandingScene() {
  const { camera } = useThree()
  const scrollRef = useRef(0)

  useEffect(() => {
    const onScroll = () => {
      scrollRef.current = window.scrollY
    }

    window.addEventListener('scroll', onScroll)
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  useFrame(() => {
    const scroll = scrollRef.current
    const y = scroll * 0.01
    const z = -20 + scroll * 0.02
    camera.position.set(-10, 15 + y, z)
    camera.lookAt(new THREE.Vector3(0, 0, 0))
  })

  return (
    <>
      <AnimeSky position={[0, 0, 0]} />
      <AnimatedPlane position={[0, 0, -5]} scale={1} rotation={[0, Math.PI, 0]} />
      <LandingText />
    </>
  )
}
