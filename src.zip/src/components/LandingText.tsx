import { Html } from '@react-three/drei'

export default function LandingText() {
  return (
    <>
      {/* 🔠 Top Left Branding */}
      <Html position={[-6, 4, -5]} transform>
        <div style={{
          color: 'white',
          fontFamily: 'monospace',
          textAlign: 'left',
          fontSize: '1.1rem',
          lineHeight: '1.6',
        }}>
          <div style={{ fontWeight: 'bold', fontSize: '1.3rem' }}>Rish</div>
          <div>© 2024</div>
          <div>All Rights Reserved.</div>
        </div>
      </Html>

      {/* 📢 Top Right Manifesto */}
      <Html position={[5.5, 4, -5]} transform>
        <div style={{
          color: 'white',
          fontFamily: 'monospace',
          textAlign: 'right',
          fontSize: '1rem',
          lineHeight: '1.4',
          maxWidth: '220px'
        }}>
          <div style={{ fontWeight: 'bold', marginBottom: '0.3rem' }}>////// Manifesto</div>
          <div>
            My mission is to <br />
            build beautiful, <br />
            immersive web <br />
            experiences—<br />
            blending creativity, <br />
            code, and 3D to <br />
            shape the web of <br />
            tomorrow.
          </div>
        </div>
      </Html>

      {/* ⬇️ Bottom Left Hint */}
      <Html position={[-7, -2.5, -5]} transform>
        <div style={{
          color: 'white',
          fontFamily: 'monospace',
          fontSize: '0.9rem',
          lineHeight: '1.4',
        }}>
          <div>Scroll down to discover.</div>
          <div>🔇 Sound: Off</div>
        </div>
      </Html>
    </>
  )
}
