import { useRef, useState } from 'react'
import { useFrame } from '@react-three/fiber'
import { Plane } from '@react-three/drei'
import AnimeCharacter from '@/components/AnimeCharacter'
import AnimeSky from '@/components/AnimeSky' // ← new import

export default function LandingScene() {
  const charRef = useRef<any>(null)
  const [hovered, setHovered] = useState(false)

  // Rotate the character slowly
  useFrame(() => {
    if (charRef.current) {
      charRef.current.rotation.y += hovered ? 0.02 : 0.01
      charRef.current.scale.setScalar(hovered ? 1.2 : 1.0)
    }
  })

  return (
    <>
      {/* Anime Sky Dome */}
      <AnimeSky scale={50} position={[0, 0, 0]} />

      {/* Lawn Ground */}
      <Plane args={[100, 100]} rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
        <meshStandardMaterial color="#1a3c2c" />
      </Plane>

      {/* Anime Character with hover animation */}
      <group
        ref={charRef}
        position={[0, 0, 0]}
        onPointerOver={() => setHovered(true)}
        onPointerOut={() => setHovered(false)}
      >
        <AnimeCharacter scale={1} />
      </group>
    </>
  )
}
